﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApl
{
    public partial class Form2 : Form
    {
        public Form2(string FilePath)
        {
            string DirPaths = Path.GetDirectoryName(FilePath) + '\\' + Path.GetFileNameWithoutExtension(FilePath) + "\\";

            InitializeComponent();
            TreeNode node = new TreeNode(DirPaths);
            chart1.Series.Clear();
            chart1.ChartAreas.Clear();

            foreach (String drive in Environment.GetLogicalDrives())
            {
                node.Nodes.Add(new TreeNode());
                treeView1.Nodes.Add(node);
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            e.Node.Nodes.Clear();
            try
            {
                foreach (string dir in Directory.GetDirectories(e.Node.FullPath)) { e.Node.Nodes.Add(Path.GetFileName(dir)); }
                setListItem(e.Node.FullPath);
            }
            catch
            {

            }
        }

        private void setListItem(String FilePath)
        {
            listView1.View = View.Details;
            listView1.Clear();
            listView1.Columns.Add("ファイル名");
            listView1.Columns.Add("ファイルサイズ");
            listView1.Columns.Add("フルパス");

            DirectoryInfo DirList = new DirectoryInfo(FilePath);
            foreach (DirectoryInfo DInfo in DirList.GetDirectories())
            {
                ListViewItem item = new ListViewItem(DInfo.Name);
                item.SubItems.Add("");
                listView1.Items.Add(item);
            }

            List<String> files = Directory.GetFiles(FilePath).ToList<String>();
            foreach (String file in files)
            {
                FileInfo info = new FileInfo(file);
                ListViewItem item = new ListViewItem(info.Name);
                item.SubItems.Add((info.Length / 1000).ToString() + "kb");
                item.SubItems.Add(info.FullName);
                listView1.Items.Add(item);
            }
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            try
            {
                foreach (ListViewItem item in listView1.SelectedItems)
                {
                    var FilePath = item.SubItems[2].Text;
                    ChartMaker();
                }
            }
            catch { }

            }

        private void ChartMaker()
        {
            try
            {
                foreach (ListViewItem item in listView1.SelectedItems)
                {

                    var FilePath = item.SubItems[2].Text;
                    chart1.Series.Clear();
                    chart1.ChartAreas.Clear();
                    string chart_area1 = "Area1";
                    chart1.ChartAreas.Add(new ChartArea(chart_area1));
                    Series series = new Series();

                    series.ChartType = SeriesChartType.Line;
                    try
                    {
                        series.LegendText = (new FileInfo(FilePath).Name);
                        FileInfo tests = new FileInfo(FilePath);

                        if (new FileInfo(FilePath).Extension == ".csv")
                        {
                            using (StreamReader sr = new StreamReader(FilePath))
                            {
                                List<string> itemlist = new List<string>();
                                while (!sr.EndOfStream)
                                {
                                    var line = sr.ReadLine();
                                    double xpoint = Double.Parse(line.Split(',')[0]);
                                    double ypoint = Double.Parse(line.Split(',')[1]);
                                    series.Points.AddXY(xpoint, ypoint);
                                }
                            }
                            chart1.Series.Add(series);
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void DCTevent(string FilePath)
        {
            chart1.Series.Dispose();
            chart1.Series.Clear();
            chart1.ChartAreas.Clear();
            string chart_area1 = "Area1";
            chart1.ChartAreas.Add(new ChartArea(chart_area1));
            Series series = new Series();
            series.ChartType = SeriesChartType.Line;
            Series series2 = new Series();
            series.LegendText = (new FileInfo(FilePath).Name);
            series2.LegendText = ("DCT-Max");

            FileInfo tests = new FileInfo(FilePath);

            List<double> source = new List<double>();

             int window = 128;

            if (new FileInfo(FilePath).Extension == ".csv")
            {
                using (StreamReader sr = new StreamReader(FilePath))
                {
                    List<string> itemlist = new List<string>();

                    while (!sr.EndOfStream)
                    {
                        var line = sr.ReadLine();
                        source.Add(double.Parse(line.Split(',')[1]));
                    }
                    var tes2 = Enumerable.Range(0, source.Count() - window).Select(i => source.Skip(i).Take(window).ToList()).ToList();
                    int x = 1;

                    foreach (var y in tes2)
                    {
                        var dcted = returnDCT(y);
                        series.Points.AddXY(x + 128, dcted.Max());
                        series2.Points.AddXY(x, source.ElementAt(x));
                        x++;
                    }

                }
            }
            chart1.Series.Add(series);
            chart1.Series.Add(series2);
        }

        private double[] returnDCT(List<double> source)
        {
            int WindowParam = 128;
            int N = WindowParam;

            double S2N = (Double)Math.Sqrt(2.0 / N);
            double SN = Math.Sqrt(N);
            long length = source.Count();
            int DCTUmax = N / 4;
            double[] sourcep = new double[N];

            for (int i = 0; i < N; i++)
            {
                if (i < length) { sourcep[i] = source[i]; }
                else { sourcep[i] = 0.0F; }
            }

            double[] dct = new double[N];
            double[] idct = new double[N];

            double[,] cs = new double[N, N];

            for (int x = 0; x < N; x++)  {   for (int u = 0; u < N; u++)   {  cs[x, u] = (float)(Math.Cos((2 * x + 1) * u * Math.PI / (2 * N)));  } }

            dct[0] = sourcep.Sum() / SN;

            for (int u = 1; u < N; u++)
            {
                dct[u] = 0.0F;
                for (int x = 0; x < N; x++)
                {
                    dct[u] += sourcep[x] * cs[x, u];
                    dct[u] *= S2N;
                }
            }

            for (int x = 0; x < N; x++)
            {
                idct[x] = 0.0F;
                for (int u = 1; u < N; u++)
                {
                    idct[x] += dct[u] * cs[x, u];
                    idct[x] = idct[x] * S2N + dct[0] / SN;
                }
            }
            double[] retdct = dct.Select(x=> x / dct.Average()).ToArray();
            return retdct;
        }

        private void Form2_DragDrop(object sender, DragEventArgs e)
        {
            string[] Filepath = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            string DirPaths = Path.GetDirectoryName(Filepath[0]) + '\\' + Path.GetFileNameWithoutExtension(Filepath[0]) + "\\";
            TreeNode node = new TreeNode(DirPaths);

            node.Nodes.Add(new TreeNode());
            treeView1.Nodes.Add(node);

        }

        private void Form2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

    }
}
